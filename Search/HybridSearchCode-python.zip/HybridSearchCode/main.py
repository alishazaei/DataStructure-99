# Developed by Ali Shazaei

class BinarySearch  :

    def __init__(self , sample , n ):
        self.sample = sample
        self.n = n
        self.last = len(self.sample)-1
        self.first = 0

    def Search (self):
        self.mid = int((self.last - self.first )/ 2)

        if  self.n  == self.sample[self.mid]  :
            print(True)
        elif len(self.sample )==1:
            print("False")
        elif self.n < self.sample[self.mid]   :
            self.last = self.mid
            self.sample = self.sample[self.first: self.last  ]
            self.Search()

        elif self.n >self.sample[self.mid]  :
            self.sample = self.sample[self.mid+1 : self.last +1 ]
            self.last = len(self.sample)-1
            self.Search()


class LinearSearch :  # o(n)
    def __init__(self , sample , n ):
       self.sample = sample
       self.n = n



    def Search (self):

        for i  in self.sample :
            if i == self.n :
                print("True")
                return True
        print("False")
        return False



class Interpolation :  #avg case = ln(ln(n)) , worst = n  ,best case = 1
    sample = []
    def __init__(self , sample  , n ):
        self.sample = sample
        self.n = n

    def Search (self) :
        last = len ( self.sample )
        first = 0

        while  last - first > 2 :
            h = int ((last-first) * (( self.n - first ) / len(self.sample)) )

            if self.n == self.sample[h] :
                return True

            if self.n < self.sample[h] :
                last = h - 1
            if self.n > self.sample[h] :
                first = h + 1

        NewArr = self.sample[first: last]
        obj = LinearSearch (NewArr, self.n)
        return obj.Search()


class HybridSearch :
    def __init__(self , sample  , n ):
        self.sample = sample
        self.n = n

    def Search (self) :
        first = 0
        last = len(self.sample) -1
        mid = last - first /2
        UseBinarySearch = False

        while last - first > 2 :
            h = int((last - first) * ( (self.n -self.sample[first])  / (self.sample[last] - self.sample[first]) ) )
            if ( self.sample[h] == self.n) :
                print("True")
                return True
            elif self.n > self.sample[h] :
                if (h <mid):
                    UseBinarySearch = True
                    #first = h + 1
                    break
                else:
                    UseBinarySearch = False
                    first = h + 1
            elif self.n < self.sample[h] :
                if ( h > mid ) :
                    UseBinarySearch = True
                    #last = h - 1
                    break
                else :
                    UseBinarySearch = False
                    last = h - 1

        NewArr = self.sample[first:last]
        if UseBinarySearch == True:
            obj =   BinarySearch(NewArr , self.n)
            obj.Search()
        else :
            obj = LinearSearch(NewArr, self.n)
            return obj.Search()




sample = [1 , 5 , 6 ,7 ,8 , 19 , 20 , 40 , 43, 45 ,58 , 68 ,79,85,99 , 102 ,103]
a  = HybridSearch(sample , 5)
a.Search()





