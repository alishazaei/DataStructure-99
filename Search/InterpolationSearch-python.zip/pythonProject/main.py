class LinearSearch :  # o(n)
    def __init__(self , sample , n ):
       self.sample = sample
       self.n = n



    def Search (self):

        for i  in self.sample :
            if i == self.n :
                return True
        return False



class Interpolation :  #avg case = ln(ln(n)) , worst = n  ,best case = 1
    sample = []
    def __init__(self , sample  , n ):
        self.sample = sample
        self.n = n

    def Search (self) :
        last = len ( self.sample )
        first = 0

        while  last - first > 2 :
            h = int ((last-first) * (( self.n - first ) / len(self.sample)) )

            if self.n == self.sample[h] :
                return True

            if self.n < self.sample[h] :
                last = h - 1
            if self.n > self.sample[h] :
                first = h + 1

        NewArr = self.sample[first: last]
        obj = LinearSearch (NewArr, self.n)
        return obj.Search()





sample = [1 , 5 , 6 ,7 ,8 , 19 , 20 , 40 , 43, 45 ,58 , 68 ,79,85,99 , 102 ,103]
a  = LinearSearch(sample , 3 )
print(a.Search())

b  = Interpolation(sample , 5 )
print(b.Search())





